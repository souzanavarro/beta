# Módulo de roteirização Wazelog
# Este pacote reúne funções de pré-processamento, otimização, pós-processamento, simulação e machine learning para rotas.
